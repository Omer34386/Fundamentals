public class Fibonacci {

    public static int fibonacci(int n) {

        if (n == 0 || n == 1) {
            return n;
        }else {
            return fibonacci(n - 1) + fibonacci(n - 2);
        }

    }

    public static void main(String[] args) {

        int n=18;  // Set the desired Fibonacci number to calculate

        try{
            if(args.length > 0) n=Integer.parseInt(args[0]);
            if (n < 0) n=18;
        }catch(Exception e){
           n=18;
        }

        long startTime = System.nanoTime();
        int result = fibonacci(n);
        long endTime = System.nanoTime();
        double executionTime = ((double)(endTime - startTime) / 1000000);

        System.out.println("Fibonacci(" + n + ") = " + result);
        System.out.printf("Execution time: %.2f milliseconds \n", executionTime);

    }

}
