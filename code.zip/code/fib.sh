#!/bin/bash

fibonacci() {
    if (( $1 == 0 || $1 == 1 )); then
        echo $1
    else
        local n1=$(( $1 - 1 ))
        local n2=$(( $1 - 2 ))
        local fib_n1=$(fibonacci $n1)
        local fib_n2=$(fibonacci $n2)
        echo $(( fib_n1 + fib_n2 ))
    fi
}

# Set the desired Fibonacci number to calculate
n=18

re='^[0-9]+$'

if [[ $1 =~ $re && $1 > 0 ]]; then
        n=$1
fi

start=$(date +%s%N)  # Start time in nanoseconds
result=$(fibonacci $n)
end=$(date +%s%N)    # End time in nanoseconds
executionTime=$(( ($end - $start) / 1000000 ))  # Convert to milliseconds
echo "Fibonacci($n) = $result"
echo "Excution time $executionTime milliseconds"
