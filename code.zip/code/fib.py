import sys
import time

def fibonacci(n):
    if n == 0 or n == 1:
        return n
    else:
        return fibonacci(n - 1) + fibonacci(n - 2)

# Set the desired Fibonacci number to calculate
n = 18

if (len(sys.argv) > 1):
    if (sys.argv[1].isdecimal()):
        n = int(sys.argv[1])

startTime = time.time()
result = fibonacci(n)
endTime = time.time()
executionTime = (endTime - startTime) * 1000
print("Fibonacci({}) = {}".format(n, result))
print("Execution time: {:.2f} milliseconds".format(executionTime))
