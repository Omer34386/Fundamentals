#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int fibonacci(int n) {
    if (n == 0 || n == 1) {
        return n;
    }else {
        return fibonacci(n - 1) + fibonacci(n - 2);
    }
}

int main(int argc, char* argv[]) {

    int n = 18;  // Set the desired Fibonacci number to calculate
    if(argc > 1){
       if(atoi(argv[1])>0){
         n = atoi(argv[1]);
       }
    }
    struct timespec startTime, endTime;
    clock_gettime(CLOCK_MONOTONIC, &startTime);
    int result = fibonacci(n);
    clock_gettime(CLOCK_MONOTONIC, &endTime);
    double executionTime = (endTime.tv_sec - startTime.tv_sec) * 1000.0;
    executionTime += (endTime.tv_nsec - startTime.tv_nsec) / 1000000.0;
    printf("Fibonacci(%d) = %d\n", n, result);
    printf("Execution time: %.2f milliseconds\n", executionTime);
    return 0;

}
